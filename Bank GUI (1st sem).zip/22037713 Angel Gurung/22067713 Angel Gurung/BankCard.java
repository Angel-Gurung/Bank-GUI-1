
/**
 * Write a description of class BankCard here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class BankCard
{
      // declareing instance variable//
   private int cardId;
   private String clientName;
   private String issuerBank;
   private String bankAccount;
   private int balanceAmount;
   //constructors with parameter//
   public BankCard(int cardId,String issuerBank,String bankAccount, int balanceAmount)
   {
       this.cardId=cardId;
       this.issuerBank=issuerBank;
       this.bankAccount=bankAccount;
       this.balanceAmount=balanceAmount;
       this.clientName="";
   }
   //Accessor method//
   public int getCardId()
   {
       return this.cardId;
   }
   public String getClientName()
   {
       return this.clientName;
   }
   public String getIssuerBank()
   {
       return this.issuerBank;
   }
   public String getbankAccount()
   {
     return this.bankAccount;  
   }
   public int getBalanceAmount()
   {
     return this.balanceAmount;
   }
   //mutator method//
   public void setclientName( String clientName)
   {
       this.clientName=clientName;
   }
   public void setBalanceAmount(int BalanceAmount)
   {
       this.balanceAmount=BalanceAmount;
   }
   //displaying //
   public void display()
   {   
    if (clientName.equals("")) 
        {
            System.out.println("Client name has not been set.");
        } 
        else
        {
            System.out.println("Card ID: " +this. cardId);
            System.out.println("Client name: " +this. clientName);
            System.out.println("Issuer bank: " +this. issuerBank);
            System.out.println("Bank account: " + this.bankAccount);
            System.out.println("Balance amount: " + this.balanceAmount);
          }
    }
   
}
